loadDataset("current", function (error, dataset) {
  // error will be null unless there is an error
  // dataset is a Recline memory store (http://reclinejs.com//docs/src/backend.memory.html).
  console.log(dataset);
});