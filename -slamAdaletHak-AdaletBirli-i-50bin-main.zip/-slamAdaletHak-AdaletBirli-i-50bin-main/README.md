# -slamAdaletHak-AdaletBirli-i-50bin
İnsanHakKoruma MazlumYetimKorumaDünya,Sınırsız,Yetki
